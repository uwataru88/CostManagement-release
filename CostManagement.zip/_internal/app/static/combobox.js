// 검색 가능한 드롭다운 (제품 등록 폼의 재료 선택, 원가계산기의 제품 선택에서 공용).
//
// Combobox.attach({
//   input, hidden, list,          // 텍스트 입력, 선택된 id 를 담는 hidden input, 목록 <ul>
//   items,                        // [{id, name, ...}] (이름순 정렬된 상태로 전달)
//   label(item) -> string,        // 목록에 표시할 문구
//   isUsed(item) -> bool,         // 다른 행에서 이미 선택된 항목이면 true (선택 불가)
//   emptyText,                    // 검색 결과가 없을 때 문구
//   onChoose(item, {byBlur}),     // 선택됨 (byBlur: 이름을 직접 정확히 입력하고 포커스를 옮긴 경우)
//   onClear(),                    // 선택이 해제됨 (입력을 고친 경우)
// })
window.Combobox = (function () {
  function attach(o) {
    const byId = new Map(o.items.map(function (i) { return [String(i.id), i]; }));
    let active = -1;
    let options = [];

    function choose(item, byBlur) {
      o.hidden.value = String(item.id);
      o.input.value = item.name;
      o.input.classList.remove("invalid");
      close();
      o.onChoose(item, { byBlur: !!byBlur });
    }

    function close() { o.list.hidden = true; active = -1; }

    function render() {
      const q = o.input.value.trim().toLowerCase();
      options = o.items.filter(function (i) { return i.name.toLowerCase().includes(q); });
      o.list.innerHTML = "";
      if (options.length === 0) {
        const li = document.createElement("li");
        li.className = "none";
        li.textContent = o.emptyText;
        o.list.appendChild(li);
      }
      options.forEach(function (item, idx) {
        const li = document.createElement("li");
        const used = o.isUsed(item);
        li.textContent = o.label(item) + (used ? " · 이미 추가됨" : "");
        if (used) li.classList.add("disabled");
        if (idx === active) li.classList.add("active");
        li.addEventListener("mousedown", function (e) {
          e.preventDefault(); // blur 방지
          if (!used) choose(item);
        });
        o.list.appendChild(li);
      });
      o.list.hidden = false;
    }

    function move(delta) {
      const n = options.length;
      if (!n) return;
      for (let step = 0; step < n; step++) {
        active = (active + delta + n) % n;
        if (!o.isUsed(options[active])) break;
      }
      render();
      const el = o.list.children[active];
      if (el) el.scrollIntoView({ block: "nearest" });
    }

    o.input.addEventListener("focus", function () { active = -1; render(); });
    o.input.addEventListener("input", function () {
      const cur = byId.get(o.hidden.value);
      if (o.hidden.value && (!cur || cur.name !== o.input.value)) {
        o.hidden.value = "";
        o.onClear();
      }
      active = -1;
      render();
    });
    o.input.addEventListener("keydown", function (e) {
      if (e.key === "ArrowDown") { e.preventDefault(); move(1); }
      else if (e.key === "ArrowUp") { e.preventDefault(); move(-1); }
      else if (e.key === "Enter") {
        if (!o.list.hidden && active >= 0 && options[active]) {
          e.preventDefault();
          if (!o.isUsed(options[active])) choose(options[active]);
        }
      } else if (e.key === "Escape") { close(); }
    });
    o.input.addEventListener("blur", function () {
      // 정확히 일치하는 이름을 직접 입력한 경우 자동 선택
      if (!o.hidden.value && o.input.value.trim()) {
        const name = o.input.value.trim().toLowerCase();
        const match = o.items.find(function (i) { return i.name.toLowerCase() === name; });
        if (match && !o.isUsed(match)) choose(match, true);
      }
      o.input.classList.toggle("invalid", !!o.input.value.trim() && !o.hidden.value);
      close();
    });
  }

  return { attach: attach };
})();
