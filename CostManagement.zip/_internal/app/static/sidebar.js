// 좌측 메뉴 접기/펼치기. 상태는 <html class="side-collapsed"> + localStorage sidebar.collapsed ("1" = 접힘).
// 처음 그릴 때의 상태 적용은 base.html <head> 의 인라인 스크립트가 한다 (깜빡임 방지). 저장이 안 되는 환경이면 이번 화면에서만 적용.
document.addEventListener("DOMContentLoaded", function () {
  const btn = document.getElementById("side-toggle");
  if (!btn) return;
  const root = document.documentElement;

  function render() {
    const collapsed = root.classList.contains("side-collapsed");
    btn.textContent = collapsed ? "»" : "«";
    btn.title = collapsed ? "메뉴 펼치기" : "메뉴 접기";
    btn.setAttribute("aria-expanded", collapsed ? "false" : "true");
  }

  btn.addEventListener("click", function () {
    const collapsed = root.classList.toggle("side-collapsed");
    try { localStorage.setItem("sidebar.collapsed", collapsed ? "1" : "0"); } catch (e) { /* 저장 실패해도 동작 */ }
    render();
  });
  render();
});
