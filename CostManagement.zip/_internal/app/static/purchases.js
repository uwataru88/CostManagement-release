// 매입 탭: 매입 입력·수정 팝업 (수단에 따른 카드사 표시, 기타 직접 입력, 금액 콤마),
// 카드 이용내역 엑셀 업로드 (파일명 검사 → 미리보기 → 선택 저장), 업로드 이력.
// 검증·저장·합계 집계는 서버(services/purchase_service.py). 여기서 하는 필수 항목 검사는 편의용이다.
// 카드사 목록은 서버 상수(CARD_COMPANIES)로 그린 <select> 옵션을 그대로 쓴다 (JS에 목록을 따로 두지 않음).
(function () {
  const dlg = document.getElementById("purchase-dialog");
  const form = document.getElementById("purchase-form");
  const el = form.elements;
  const CARD_OTHER = form.dataset.cardOther;
  const cardFields = document.getElementById("card-fields");
  const otherField = document.getElementById("card-other-field");
  const deleteBtn = document.getElementById("purchase-delete");
  const employeeSelect = document.getElementById("vendor-employee");  // 매입구분이 인건비일 때 거래처 대신 보이는 직원 선택

  function digits(v) { return String(v || "").replace(/[^\d]/g, ""); }
  function comma(n) { return n === "" ? "" : Number(n).toLocaleString("ko-KR"); }

  // ---------- 금액: 숫자만, 천 단위 콤마 (커서 위치 유지) ----------
  el.amount.addEventListener("input", function () {
    const input = el.amount;
    const afterCaret = digits(input.value.slice(input.selectionStart)).length;
    input.value = comma(digits(input.value).replace(/^0+(?=\d)/, ""));
    let pos = input.value.length, seen = 0;
    while (pos > 0 && seen < afterCaret) { pos--; if (/\d/.test(input.value[pos])) seen++; }
    input.setSelectionRange(pos, pos);
  });

  // ---------- 수단 / 카드사 표시 ----------
  function method() {
    const r = form.querySelector('input[name="payment_method"]:checked');
    return r ? r.value : "";
  }
  function cardListHas(name) {
    return Array.prototype.some.call(el.card_company.options, function (o) { return o.value && o.value !== CARD_OTHER && o.value === name; });
  }
  function refreshCardFields() {
    const isCard = method() === "card";
    cardFields.hidden = !isCard;
    if (!isCard) {  // 현금: 카드사 드롭다운·직접 입력 값을 비운다
      el.card_company.value = "";
      el.card_company_other.value = "";
    }
    const isOther = isCard && el.card_company.value === CARD_OTHER;
    otherField.hidden = !isOther;
    if (!isOther) el.card_company_other.value = "";
  }
  form.querySelectorAll('input[name="payment_method"]').forEach(function (r) {
    r.addEventListener("change", function () { refreshCardFields(); clearError("payment_method"); clearError("card_company"); clearError("card_company_other"); });
  });
  el.card_company.addEventListener("change", function () {
    refreshCardFields();
    clearError("card_company");
    clearError("card_company_other");
    if (el.card_company.value === CARD_OTHER) el.card_company_other.focus();
  });

  // ---------- 필수 항목 안내 ----------
  function errorEl(name) { return form.querySelector('[data-error-for="' + name + '"]'); }
  function setError(name, text) {
    const p = errorEl(name);
    p.textContent = text;
    p.hidden = false;
    const input = name === "payment_method" ? null : el[name];
    if (input) input.classList.add("invalid");
    if (name === "vendor") employeeSelect.classList.add("invalid");
  }
  function clearError(name) {
    const p = errorEl(name);
    p.textContent = "";
    p.hidden = true;
    const input = name === "payment_method" ? null : el[name];
    if (input) input.classList.remove("invalid");
    if (name === "vendor") employeeSelect.classList.remove("invalid");
  }
  function clearErrors() {
    ["category_id", "purchase_date", "vendor", "amount", "payment_method", "card_company", "card_company_other"].forEach(clearError);
  }
  ["purchase_date", "vendor", "amount", "card_company_other"].forEach(function (name) {
    el[name].addEventListener("input", function () { clearError(name); });
  });

  function validate() {
    clearErrors();
    let first = null;
    function fail(name, text) {
      setError(name, text);
      if (!first) first = name === "payment_method" ? form.querySelector('input[name="payment_method"]')
        : (name === "vendor" && isLabor() ? employeeSelect : el[name]);
    }
    if (!el.category_id.value) fail("category_id", "매입구분을 선택하세요.");
    if (!el.purchase_date.value) fail("purchase_date", "일자를 선택하세요.");
    if (!el.vendor.value.trim()) fail("vendor", isLabor() ? "직원을 선택하세요." : "거래처를 입력하세요.");
    if (Number(digits(el.amount.value) || 0) < 1) fail("amount", "금액을 1원 이상 입력하세요.");
    const m = method();
    if (!m) fail("payment_method", "수단(카드/현금)을 선택하세요.");
    if (m === "card") {
      if (!el.card_company.value) fail("card_company", "카드사를 선택하세요.");
      else if (el.card_company.value === CARD_OTHER && !el.card_company_other.value.trim()) fail("card_company_other", "카드사명을 입력하세요.");
    }
    if (first) first.focus();
    return !first;
  }

  form.addEventListener("submit", function (e) {
    if (e.submitter === deleteBtn) return;  // 삭제는 검사하지 않음
    if (!validate()) e.preventDefault();
  });

  // ---------- 팝업 열기 ----------
  // 서버 오류로 다시 열린 팝업의 오류 상자는 다른 매입을 열 때 지운다
  function clearServerErrors() {
    const box = form.querySelector(".modal-errors");
    if (box) box.remove();
    form.dataset.alert = "";
  }

  function setMode(id) {
    el.id.value = id || "";
    form.action = id ? "/sales/purchases/records/" + id + form.dataset.query : form.dataset.newAction;
    document.getElementById("purchase-title").textContent = id ? "매입 수정" : "매입 입력";
    deleteBtn.hidden = !id;
  }
  function setMethod(value) {
    form.querySelectorAll('input[name="payment_method"]').forEach(function (r) { r.checked = r.value === value; });
  }
  // 매입구분: 수정 중인 매입의 구분이 '사용 안 함'이면 드롭다운에 현재 값으로만 임시 표시한다
  const CATEGORY_NAMES = JSON.parse(form.dataset.categoryNames || "{}");
  // 매입구분 필터: 고르면 바로 조회 (같은 달). 리스트·합계·통계가 모두 그 구분 기준
  const filter = document.getElementById("cat-filter");
  filter.addEventListener("change", function () { filter.form.submit(); });
  function setCategory(id) {
    el.category_id.querySelectorAll("option[data-temp]").forEach(function (o) { o.remove(); });
    id = String(id || "");
    if (id && !el.category_id.querySelector('option[value="' + id + '"]') && CATEGORY_NAMES[id]) {
      const o = document.createElement("option");
      o.value = id;
      o.textContent = CATEGORY_NAMES[id] + " (사용 안 함)";
      o.dataset.temp = "1";
      el.category_id.appendChild(o);
    }
    el.category_id.value = id;
  }

  // ---------- 매입구분 '인건비': 거래처 = 직원 선택, 수단 = 현금, 일자 = 그달 말일 ----------
  // 직원 드롭다운에서 고른 이름을 거래처 칸(name="vendor", 숨김)에 넣어 보낸다. 서버도 직원 이름인지 확인한다
  const LABOR_CATEGORY = form.dataset.laborCategory;
  function isLabor() { return !!LABOR_CATEGORY && el.category_id.value === LABOR_CATEGORY; }

  function syncVendorMode() {
    const labor = isLabor();
    el.vendor.hidden = labor;
    employeeSelect.hidden = !labor;
    if (labor) {
      const name = el.vendor.value.trim();
      const has = Array.prototype.some.call(employeeSelect.options, function (o) { return o.value && o.value === name; });
      employeeSelect.value = has ? name : "";
      if (!has) el.vendor.value = "";  // 직원이 아닌 거래처는 비우고 다시 고르게 한다
    }
  }
  employeeSelect.addEventListener("change", function () {
    el.vendor.value = employeeSelect.value;
    clearError("vendor");
  });

  function monthEnd(dateStr) {
    const m = /^(\d{4})-(\d{2})/.exec(dateStr || "");
    if (!m) return dateStr;
    const last = new Date(Number(m[1]), Number(m[2]), 0).getDate();  // 다음 달 0일 = 이번 달 말일
    return m[1] + "-" + m[2] + "-" + String(last).padStart(2, "0");
  }

  el.category_id.addEventListener("change", function () {
    clearError("category_id");
    syncVendorMode();
    if (isLabor()) {  // 사용자가 인건비를 고를 때만 (수정 팝업을 열 때는 저장된 값 유지)
      setMethod("cash");
      refreshCardFields();
      clearError("payment_method");
      el.purchase_date.value = monthEnd(el.purchase_date.value || form.dataset.defaultDate);
      clearError("purchase_date");
    }
  });

  // 저장된 카드사명 -> 드롭다운 값. 목록에 없으면 '기타' + 직접 입력
  function setCardCompany(name) {
    if (!name) { el.card_company.value = ""; el.card_company_other.value = ""; return; }
    if (cardListHas(name)) { el.card_company.value = name; el.card_company_other.value = ""; }
    else { el.card_company.value = CARD_OTHER; el.card_company_other.value = name; }
  }

  function openNew() {
    clearServerErrors();
    setMode("");
    // 매입구분 필터를 고른 상태면 그 구분을 기본값으로 (사용 중인 구분일 때만)
    const filtered = filter.value && el.category_id.querySelector('option[value="' + filter.value + '"]:not([data-temp])');
    setCategory(filtered ? filter.value : "");
    el.purchase_date.value = form.dataset.defaultDate;
    el.vendor.value = "";
    el.amount.value = "";
    el.memo.value = "";
    showExcelInfo(null);
    document.getElementById("labor-info").hidden = true;
    setMethod("");
    setCardCompany("");
    syncVendorMode();
    if (isLabor()) {  // 매입구분 필터가 인건비면 새 매입도 인건비 기본값 (현금, 그달 말일)
      setMethod("cash");
      el.purchase_date.value = monthEnd(el.purchase_date.value);
    }
    refreshCardFields();
    clearErrors();
    dlg.showModal();
    (el.category_id.value ? (isLabor() ? employeeSelect : el.vendor) : el.category_id).focus();
  }

  function openEdit(d) {
    clearServerErrors();
    setMode(d.id);
    setCategory(d.category);
    el.purchase_date.value = d.date;
    el.vendor.value = d.vendor;
    el.amount.value = comma(digits(d.amount));
    setMethod(d.method);
    setCardCompany(d.cardCompany);
    refreshCardFields();
    el.memo.value = d.memo;
    showExcelInfo(d.source === "excel" ? d : null);
    document.getElementById("labor-info").hidden = !d.labor;
    syncVendorMode();
    clearErrors();
    dlg.showModal();
  }

  document.getElementById("new-purchase").addEventListener("click", openNew);

  // ---------- 일괄삭제: [일괄삭제] → 체크박스 열 표시, 행을 누르면 체크 전환 → [선택 삭제] ----------
  const table = document.getElementById("purchase-table");
  const bulkForm = document.getElementById("bulk-delete-form");
  let selecting = false;
  function selBoxes() { return Array.prototype.slice.call(document.querySelectorAll(".sel-row")); }
  function updateBulk() {
    const sel = selBoxes().filter(function (c) { return c.checked; });
    const total = sel.reduce(function (a, c) { return a + Number(c.dataset.amount); }, 0);
    const btn = document.getElementById("bulk-delete");
    btn.disabled = sel.length === 0;
    btn.textContent = sel.length ? "선택 삭제 (" + sel.length + "건 · " + total.toLocaleString("ko-KR") + "원)" : "선택 삭제";
    const all = document.getElementById("sel-all");
    all.checked = sel.length > 0 && sel.length === selBoxes().length;
    all.indeterminate = sel.length > 0 && sel.length < selBoxes().length;
    selBoxes().forEach(function (c) { c.closest("tr").classList.toggle("selected", c.checked); });
    return { count: sel.length, total: total };
  }
  function setSelecting(on) {
    selecting = on;
    table.classList.toggle("selecting", on);
    document.getElementById("bulk-mode").hidden = on;
    document.getElementById("bulk-delete").hidden = !on;
    document.getElementById("bulk-cancel").hidden = !on;
    if (!on) selBoxes().forEach(function (c) { c.checked = false; });
    updateBulk();
  }
  if (table) {
    document.getElementById("bulk-mode").addEventListener("click", function () { setSelecting(true); });
    document.getElementById("bulk-cancel").addEventListener("click", function () { setSelecting(false); });
    document.getElementById("sel-all").addEventListener("change", function (e) {
      selBoxes().forEach(function (c) { c.checked = e.target.checked; });
      updateBulk();
    });
    selBoxes().forEach(function (c) {
      c.addEventListener("click", function (e) { e.stopPropagation(); });
      c.addEventListener("change", updateBulk);
    });
    document.getElementById("bulk-delete").addEventListener("click", function () {
      const s = updateBulk();
      if (!s.count) return;
      if (!confirm("선택한 매입 " + s.count + "건(" + s.total.toLocaleString("ko-KR") + "원)을 삭제할까요?\n삭제한 매입은 되돌릴 수 없습니다.")) return;
      bulkForm.submit();
    });
  }

  document.querySelectorAll(".purchase-row").forEach(function (row) {
    function go() {
      if (selecting) {  // 선택 모드: 수정 팝업 대신 체크 전환
        const cb = row.querySelector(".sel-row");
        cb.checked = !cb.checked;
        updateBulk();
        return;
      }
      openEdit(row.dataset);
    }
    row.addEventListener("click", go);
    row.addEventListener("keydown", function (e) { if (e.key === "Enter") go(); });
  });

  // ---------- 삭제 / 닫기 ----------
  deleteBtn.addEventListener("click", function (e) {
    const label = el.vendor.value.trim() + " " + (el.amount.value || "0") + "원";
    if (!confirm(el.purchase_date.value + " " + label + " 매입을 삭제할까요?")) { e.preventDefault(); return; }
    deleteBtn.formAction = "/sales/purchases/records/" + el.id.value + "/delete" + form.dataset.query;
  });
  // 매출 팝업과 같이 [닫기] 버튼(또는 저장·삭제)으로만 닫는다 — 바깥 클릭·Esc 로는 닫히지 않음
  dlg.querySelector(".close-dialog").addEventListener("click", function () { dlg.close(); });
  dlg.addEventListener("cancel", function (e) { e.preventDefault(); });
  dlg.addEventListener("keydown", function (e) { if (e.key === "Escape") e.preventDefault(); });

  // 서버 검증 오류로 다시 그려진 경우: 입력값 그대로 팝업 다시 열기
  if (dlg.dataset.open) {
    setMode(el.id.value);
    setCategory(form.dataset.modalCategory);
    syncVendorMode();
    refreshCardFields();
    dlg.showModal();
    // 추가경비·인건비 중복(같은 일자 + 같은 거래처)으로 저장이 막힌 경우 알림
    if (form.dataset.alert) window.alert(form.dataset.alert);
  }

  // 엑셀로 들어온 건: 수정 폼에 승인번호·이용구분을 읽기 전용으로 표시
  function showExcelInfo(d) {
    document.getElementById("excel-info").hidden = !d;
    document.getElementById("info-approval").textContent = d ? (d.approval || "-") : "";
    document.getElementById("info-usage").textContent = d ? (d.usage || "-") : "";
  }

  // ---------- 카드 이용내역 엑셀 업로드 ----------
  // 1) 파일 선택 → 2) 파일명 규칙 검사 (하나라도 위반이면 경고창 + 전체 취소, 서버 요청 없음)
  // 3) 서버 해석 (저장 안 함) → 4) 미리보기에서 행 선택 → 5) 저장 → 6) 이용월로 이동
  const fileInput = document.getElementById("excel-file");
  const CARD_COMPANIES = JSON.parse(fileInput.dataset.cardCompanies);
  const nameDlg = document.getElementById("filename-dialog");
  const importDlg = document.getElementById("import-dialog");
  const importRows = document.getElementById("import-rows");
  const importSave = document.getElementById("import-save");
  const importError = document.getElementById("import-error");
  const checkAll = document.getElementById("import-check-all");
  const uploadBtn = document.getElementById("excel-upload");
  let preview = [];   // 서버 미리보기 결과 (files)

  function onExcelUploadClick() {
    fileInput.value = "";
    fileInput.click();
  }

  function resetFileInput() { fileInput.value = ""; }

  // 파일명 규칙 위반 경고창 (화면 검사·서버 검사 공용)
  function showFilenameErrors(bad) {
    const ul = document.getElementById("filename-errors");
    ul.textContent = "";
    bad.forEach(function (f) {
      const li = document.createElement("li");
      const name = document.createElement("div");
      name.className = "fname";
      name.textContent = f.file_name;
      const reasons = document.createElement("div");
      reasons.className = "reasons";
      reasons.textContent = f.errors.join(" / ");
      li.appendChild(name);
      li.appendChild(reasons);
      ul.appendChild(li);
    });
    nameDlg.showModal();
  }
  // [확인]: 경고창을 닫고 파일 선택 상태 초기화
  document.getElementById("filename-ok").addEventListener("click", function () { nameDlg.close(); });
  nameDlg.addEventListener("close", resetFileInput);

  fileInput.addEventListener("change", function () {
    const files = Array.prototype.slice.call(fileInput.files || []);
    if (!files.length) return;
    const check = window.checkCardFiles(files.map(function (f) { return f.name; }), CARD_COMPANIES);
    if (!check.ok) { showFilenameErrors(check.bad); return; }   // 전체 취소 (서버로 보내지 않음)
    uploadForPreview(files);
  });

  function uploadForPreview(files) {
    const fd = new FormData();
    files.forEach(function (f) { fd.append("files", f, f.name); });
    uploadBtn.disabled = true;
    uploadBtn.textContent = "파일 읽는 중…";
    fetch("/sales/purchases/import/preview", { method: "POST", body: fd })
      .then(function (r) { return r.json(); })
      .then(function (body) {
        if (body.kind === "filename") { showFilenameErrors(body.files); return; }   // 서버 검사에서 위반 (같은 경고창)
        if (!body.ok) { alert((body.errors || ["파일을 읽지 못했습니다."]).join("\n")); resetFileInput(); return; }
        openPreview(body.files);
      })
      .catch(function () { alert("파일을 보내지 못했습니다. 프로그램이 실행 중인지 확인하세요."); resetFileInput(); })
      .finally(function () { uploadBtn.disabled = false; uploadBtn.textContent = "엑셀 업로드"; });
  }

  // ---------- 미리보기 ----------
  function td(text, cls) {
    const c = document.createElement("td");
    if (cls) c.className = cls;
    c.textContent = text;
    return c;
  }

  function renderFiles(files) {
    const box = document.getElementById("import-files");
    box.textContent = "";
    files.forEach(function (f) {
      const div = document.createElement("div");
      div.className = "import-file" + (f.error ? " has-error" : "");
      const c = f.counts;
      const ym = f.year_month.split("-");
      const parts = [["fname", f.file_name], ["", f.card_company + " · 이용월 " + ym[0] + "년 " + Number(ym[1]) + "월"]];
      if (f.error) {
        parts.push(["", f.error]);
      } else {
        parts.push(["muted", f.profile_name + " · " + f.kind]);
        parts.push(["", "정상 " + c.normal + " · 취소 " + c.cancel + " · 중복 " + c.duplicate +
                        " · 월 범위 밖 " + c.out_of_month + " · 오류 " + c.error]);
      }
      parts.forEach(function (p) {
        const span = document.createElement("span");
        if (p[0]) span.className = p[0];
        span.textContent = p[1];
        div.appendChild(span);
      });
      box.appendChild(div);
    });
  }

  function renderRows(files) {
    importRows.textContent = "";
    files.forEach(function (f, fi) {
      if (!f.rows.length) return;
      if (files.length > 1) {
        const sep = document.createElement("tr");
        sep.className = "file-sep";
        const c = td(f.file_name + " (" + f.rows.length + "행)");
        c.colSpan = 8;
        sep.appendChild(c);
        importRows.appendChild(sep);
      }
      f.rows.forEach(function (r, ri) {
        const tr = document.createElement("tr");
        tr.className = "st-" + r.status;
        const cb = document.createElement("input");
        cb.type = "checkbox";
        cb.className = "import-check";
        cb.checked = r.checked;
        cb.disabled = !r.checkable;
        cb.dataset.file = fi;
        cb.dataset.row = ri;
        const first = document.createElement("td");
        first.appendChild(cb);
        tr.appendChild(first);
        tr.appendChild(td(r.purchase_date, "nowrap"));
        const v = td(r.vendor, "vendor");
        v.title = r.vendor;
        tr.appendChild(v);
        tr.appendChild(td(r.amount === null ? "-" : r.amount.toLocaleString("ko-KR"), "num"));
        tr.appendChild(td(f.card_company, "nowrap"));
        tr.appendChild(td(r.approval_no, "nowrap"));
        tr.appendChild(td(r.usage_type, "nowrap"));
        const st = td(r.label, "st-label");
        if (r.note) {
          const note = document.createElement("span");
          note.className = "st-note";
          note.textContent = r.note;
          st.appendChild(note);
        }
        tr.appendChild(st);
        // 행 아무 곳이나 클릭해도 체크 전환 (체크 가능한 행만)
        tr.addEventListener("click", function (e) {
          if (e.target === cb || cb.disabled) return;
          cb.checked = !cb.checked;
          updateSummary();
        });
        importRows.appendChild(tr);
      });
    });
  }

  function checkedBoxes() {
    return Array.prototype.filter.call(importRows.querySelectorAll(".import-check"), function (cb) {
      return cb.checked && !cb.disabled;
    });
  }

  function rowOf(cb) { return preview[cb.dataset.file].rows[cb.dataset.row]; }

  function updateSummary() {
    const sel = checkedBoxes();
    const total = sel.reduce(function (acc, cb) { return acc + (rowOf(cb).amount || 0); }, 0);
    document.getElementById("import-count").textContent = sel.length.toLocaleString("ko-KR");
    document.getElementById("import-total").textContent = total.toLocaleString("ko-KR");
    importSave.disabled = sel.length === 0;
    const enabled = importRows.querySelectorAll(".import-check:not(:disabled)");
    checkAll.checked = enabled.length > 0 && sel.length === enabled.length;
    checkAll.indeterminate = sel.length > 0 && sel.length < enabled.length;
  }

  importRows.addEventListener("change", function (e) {
    if (e.target.classList.contains("import-check")) updateSummary();
  });
  checkAll.addEventListener("change", function () {
    importRows.querySelectorAll(".import-check:not(:disabled)").forEach(function (cb) { cb.checked = checkAll.checked; });
    updateSummary();
  });

  function openPreview(files) {
    preview = files;
    importError.hidden = true;
    renderFiles(files);
    renderRows(files);
    updateSummary();
    importDlg.showModal();
  }

  // [저장]: 선택한 행만 파일별로 묶어 보낸다 (서버가 다시 검증·중복 확인)
  importSave.addEventListener("click", function () {
    const byFile = {};
    const order = [];
    checkedBoxes().forEach(function (cb) {
      const f = preview[cb.dataset.file];
      const r = rowOf(cb);
      if (!byFile[cb.dataset.file]) {
        byFile[cb.dataset.file] = { file_name: f.file_name, profile: f.profile, rows: [] };
        order.push(cb.dataset.file);
      }
      byFile[cb.dataset.file].rows.push({ purchase_date: r.purchase_date, vendor: r.vendor, amount: r.amount,
                                          approval_no: r.approval_no, usage_type: r.usage_type });
    });
    if (!order.length) return;
    importSave.disabled = true;
    fetch("/sales/purchases/import/save", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ files: order.map(function (k) { return byFile[k]; }) }),
    })
      .then(function (r) { return r.json(); })
      .then(function (res) {
        if (res.ok) { window.location.href = res.redirect; return; }
        importError.textContent = (res.errors || ["저장하지 못했습니다."]).join(" / ");
        importError.hidden = false;
        importSave.disabled = false;
      })
      .catch(function () {
        importError.textContent = "저장 요청을 보내지 못했습니다.";
        importError.hidden = false;
        importSave.disabled = false;
      });
  });

  // 미리보기는 [닫기]로만 닫는다 (매입 팝업과 같은 규칙). 닫으면 파일 선택도 초기화
  document.getElementById("import-close").addEventListener("click", function () { importDlg.close(); });
  importDlg.addEventListener("close", resetFileInput);
  [importDlg, nameDlg].forEach(function (d) {
    d.addEventListener("cancel", function (e) { e.preventDefault(); });
  });

  uploadBtn.addEventListener("click", onExcelUploadClick);

  // ---------- 업로드 이력 ----------
  const historyDlg = document.getElementById("history-dialog");
  document.getElementById("import-history").addEventListener("click", function () { historyDlg.showModal(); });
  historyDlg.querySelector(".close-dialog").addEventListener("click", function () { historyDlg.close(); });

})();
