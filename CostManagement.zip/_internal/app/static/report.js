// 결산통계 탭: 하위 탭 전환 (매출통계 / 매입통계 / 결산통계, 매입통계 안의 매입구분별 / 카드사별 / 거래처별 / 일별).
// 서버가 그달 표를 모두 그려 두고 여기서는 숨김/표시만 바꾼다. 그룹별 선택은 localStorage 에 기억 (실패하면 첫 번째 탭)
(function () {
  function load(key, allowed) {
    try {
      const v = window.localStorage.getItem(key);
      return allowed.indexOf(v) >= 0 ? v : allowed[0];
    } catch (e) {
      return allowed[0];
    }
  }
  function save(key, v) {
    try { window.localStorage.setItem(key, v); } catch (e) { /* 저장 실패는 무시 */ }
  }

  document.querySelectorAll(".sub-tabs[data-group]").forEach(function (bar) {
    const group = bar.dataset.group;
    const key = "report.tab." + group;
    const buttons = Array.prototype.slice.call(bar.querySelectorAll("[data-tab]"));
    const names = buttons.map(function (b) { return b.dataset.tab; });

    function apply(v) {
      buttons.forEach(function (b) {
        const on = b.dataset.tab === v;
        b.classList.toggle("active", on);
        b.setAttribute("aria-selected", on ? "true" : "false");
      });
      document.querySelectorAll('.tab-panel[data-group="' + group + '"]').forEach(function (p) {
        p.hidden = p.dataset.panel !== v;
      });
    }
    buttons.forEach(function (b) {
      b.addEventListener("click", function () { apply(b.dataset.tab); save(key, b.dataset.tab); });
    });
    apply(load(key, names));
  });
})();
