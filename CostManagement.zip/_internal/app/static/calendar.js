// 근무관리 달력: 이름 클릭 -> 수정 팝업, + -> 근무 추가 팝업.
// 저장은 일반 form POST (서버에서 검증 후 같은 달로 리다이렉트).
(function () {
  function minutes(t) { const p = t.split(":"); return Number(p[0]) * 60 + Number(p[1]); }

  function fmt(m) { const h = Math.floor(m / 60), r = m % 60; return h && r ? h + "시간 " + r + "분" : r ? r + "분" : h + "시간"; }

  function checkRange(form, e) {
    const start = form.querySelector('[name="start_time"]').value;
    const end = form.querySelector('[name="end_time"]').value;
    const brk = Number(form.querySelector('[name="break_minutes"]').value || 0);
    if (minutes(end) <= minutes(start)) {
      e.preventDefault();
      alert("종료시간은 시작시간보다 늦어야 합니다. (" + start + "~" + end + ")");
      return false;
    }
    if (brk && brk >= minutes(end) - minutes(start)) {
      e.preventDefault();
      alert("휴게시간이 근무시간보다 길거나 같습니다.");
      return false;
    }
    return true;
  }

  // 팝업의 실 근무시간 안내 (종료 − 시작 − 휴게, 표시용 — 계산은 서버 work_summary.record_minutes)
  function showNet(form) {
    const start = form.querySelector('[name="start_time"]').value;
    const end = form.querySelector('[name="end_time"]').value;
    const brk = Number(form.querySelector('[name="break_minutes"]').value || 0);
    const net = minutes(end) - minutes(start) - brk;
    form.querySelector(".net-time").textContent = net > 0 ? "실 근무시간 " + fmt(net) + (brk ? " (휴게 " + fmt(brk) + " 제외)" : "") : "";
  }
  document.querySelectorAll("#edit-form, #add-form").forEach(function (f) {
    f.addEventListener("change", function () { showNet(f); });
  });

  // 정산 팝업에 저장하지 않은 수정값이 있으면 닫기 전에 확인
  let settleDirty = false;
  function canClose(dlg) {
    return dlg.id !== "settle-dialog" || !settleDirty ||
      confirm("저장하지 않은 정산 수정값이 있습니다. 닫으면 사라집니다. 닫을까요?");
  }
  document.querySelectorAll(".close-dialog").forEach(function (btn) {
    btn.addEventListener("click", function () { const dlg = btn.closest("dialog"); if (canClose(dlg)) dlg.close(); });
  });
  // 팝업 바깥(배경) 클릭 시 닫기 (Esc 도 같은 확인)
  document.querySelectorAll("dialog.modal").forEach(function (dlg) {
    dlg.addEventListener("click", function (e) { if (e.target === dlg && canClose(dlg)) dlg.close(); });
    dlg.addEventListener("cancel", function (e) { if (!canClose(dlg)) e.preventDefault(); });
  });

  // ---------- 근무 수정 ----------
  const editDlg = document.getElementById("edit-dialog");
  const editForm = document.getElementById("edit-form");
  const btnOff = document.getElementById("btn-off");
  const btnOn = document.getElementById("btn-on");

  document.querySelectorAll(".chip").forEach(function (chip) {
    chip.addEventListener("click", function () {
      const d = chip.dataset;
      const off = d.status === "off";
      editForm.action = "/attendance/work/records/" + d.id;
      document.getElementById("edit-title").textContent = d.label + " " + d.name + (off ? " · 휴무" : "");
      document.getElementById("edit-meta").textContent =
        d.source + (d.retired ? " · 퇴사한 직원" : "") + (off ? " · 휴무 취소 시 " + d.start + "~" + d.end + " 근무로 돌아갑니다" : "");
      editForm.querySelector('[name="start_time"]').value = d.start;
      editForm.querySelector('[name="end_time"]').value = d.end;
      editForm.querySelector('[name="break_minutes"]').value = d.break || "0";
      showNet(editForm);
      btnOff.hidden = off;
      btnOn.hidden = !off;
      editDlg.showModal();
    });
  });

  editForm.addEventListener("submit", function (e) {
    const action = e.submitter && e.submitter.value;
    if (action === "update") { checkRange(editForm, e); return; }
    if (action === "delete" &&
        !confirm("이 근무 기록을 삭제할까요?\n삭제 후 근무동기화를 하면 기본 일정이 있는 경우 다시 생성됩니다.")) {
      e.preventDefault();
    }
  });

  // ---------- 정산 ----------
  const settleDlg = document.getElementById("settle-dialog");
  const settleBody = document.getElementById("settle-body");
  const settlePrint = document.getElementById("settle-print");
  const settleSave = document.getElementById("settle-save");

  // 세금계산 버튼: 서버에서 계산해 둔 세금 내역을 펼치거나 접는다 (세금 방식이 '없음'인 직원은 버튼이 없다)
  // 금액 부분을 다시 그린 뒤에도 펼친 상태(open)를 유지한다
  function bindTax(open) {
    const taxBtn = settleBody.querySelector(".tax-btn");
    const taxBox = settleBody.querySelector(".tax-box");
    if (!taxBtn) return;
    function show(isOpen) {
      taxBox.hidden = !isOpen;
      taxBtn.setAttribute("aria-expanded", String(isOpen));
      taxBtn.textContent = isOpen ? "세금계산 닫기" : taxBtn.dataset.label;
    }
    show(open);
    taxBtn.addEventListener("click", function () {
      show(taxBox.hidden);
      if (!taxBox.hidden) taxBox.scrollIntoView({ block: "nearest" });
    });
  }

  // 주휴수당 표 직접 수정: 고칠 때마다 서버가 금액·세금을 다시 계산(/attendance/work/settlement/preview)한다.
  // [저장] → /attendance/work/settlement/save. 저장 전 값은 인쇄 주소에 adj 로 붙여 그 인쇄에만 반영
  function bindWeekEdit(printBase) {
    const box = settleBody.querySelector(".settle-edit");
    settlePrint.href = printBase;
    settlePrint.classList.remove("disabled");
    settleSave.classList.remove("primary");
    settleSave.onclick = null;
    settleSave.hidden = !box;
    settleDirty = false;
    if (!box) return;
    const errorsEl = box.querySelector(".settle-edit-errors");
    const norm = function (v) { return String(v || "").replace(/\s+/g, ""); };
    let timer = null;
    let seq = 0;
    let valid = true;

    // 서버에 보낼 수정값 = 계산값과 다른 근무시간·주휴시간 + 직접 입력한 주휴수당
    function collect() {
      const weeks = [];
      box.querySelectorAll(".week-row").forEach(function (row) {
        const item = { start: row.dataset.start };
        let changed = false;
        row.querySelectorAll(".week-input").forEach(function (inp) {
          const field = inp.dataset.field;
          const send = field === "pay" ? inp.dataset.manual === "1" : norm(inp.value) !== norm(inp.dataset.calc);
          inp.classList.toggle("changed", norm(inp.value) !== norm(inp.dataset.calc));
          if (send) { item[field] = inp.value; changed = true; }
        });
        if (changed) weeks.push(item);
      });
      return weeks;
    }
    // 처음 연 값(저장된 값)과 다른지
    function isDirty() {
      return Array.prototype.some.call(box.querySelectorAll(".week-input"), function (inp) {
        return norm(inp.value) !== norm(inp.dataset.orig) ||
          (inp.dataset.field === "pay" && (inp.dataset.manual === "1") !== (inp.dataset.manualOrig === "1"));
      });
    }
    function showErrors(list) {
      errorsEl.innerHTML = "";
      (list || []).forEach(function (m) {
        const li = document.createElement("li");
        li.textContent = m;
        errorsEl.appendChild(li);
      });
      errorsEl.hidden = !list || !list.length;
    }
    // 저장·인쇄 버튼 상태는 입력할 때마다 바로 맞춘다 (서버 계산을 기다리지 않음 — 기다리는 동안 누른 클릭이 무시되던 문제)
    // 인쇄 주소: 저장하지 않은 값은 adj 로 붙인다 (저장된 수정값 대신 이 값으로 인쇄 — 빈 목록이면 계산값)
    function updateButtons() {
      settleDirty = isDirty();
      settleSave.classList.toggle("primary", settleDirty);
      settlePrint.href = settleDirty ? printBase + "&adj=" + encodeURIComponent(JSON.stringify(collect())) : printBase;
      settlePrint.classList.toggle("disabled", !valid);
    }

    function refresh() {
      const weeks = collect();
      const mine = ++seq;
      const taxBox = settleBody.querySelector(".tax-box");
      const taxOpen = !!(taxBox && !taxBox.hidden);
      fetch("/attendance/work/settlement/preview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ym: box.dataset.ym, employee_id: box.dataset.employee, weeks: weeks }),
      }).then(function (r) { return r.json(); }).then(function (res) {
        if (mine !== seq) return;   // 더 나중 요청의 결과만 반영
        valid = !!res.ok;
        showErrors(res.ok ? [] : (res.errors || ["계산하지 못했습니다."]));
        if (res.ok) {
          res.weeks.forEach(function (w) {
            const row = box.querySelector('.week-row[data-start="' + w.start + '"]');
            const pay = row && row.querySelector('[data-field="pay"]');
            if (pay && pay.dataset.manual !== "1") {
              pay.value = w.pay.toLocaleString("ko-KR");
              pay.classList.toggle("changed", norm(pay.value) !== norm(pay.dataset.calc));
            }
          });
          settleBody.querySelector(".settle-amounts").innerHTML = res.html;
          bindTax(taxOpen);
        }
        updateButtons();
      }).catch(function () {
        if (mine !== seq) return;
        valid = false;
        showErrors(["계산 요청에 실패했습니다. 프로그램을 다시 실행한 뒤 화면을 새로고침해 주세요."]);
        updateButtons();
      });
    }
    function schedule() {
      updateButtons();
      clearTimeout(timer);
      timer = setTimeout(refresh, 300);
    }

    box.querySelectorAll(".week-input").forEach(function (inp) {
      inp.addEventListener("input", function () {
        if (inp.dataset.field === "pay") {
          inp.dataset.manual = "1";
        } else if (inp.dataset.field === "allow") {
          // 주휴시간을 고치면 주휴수당은 다시 '주휴시간 × 시급'
          delete inp.closest(".week-row").querySelector('[data-field="pay"]').dataset.manual;
        }
        schedule();
      });
    });
    box.querySelector(".week-reset").addEventListener("click", function () {
      box.querySelectorAll(".week-input").forEach(function (inp) {
        inp.value = inp.dataset.calc;
        delete inp.dataset.manual;
      });
      clearTimeout(timer);
      updateButtons();
      refresh();
    });

    settleSave.onclick = function () {
      clearTimeout(timer);   // 계산 대기 중이어도 지금 입력값으로 바로 저장 (검사는 서버)
      if (!isDirty()) {
        alert("고친 값이 없습니다. 주휴수당 표의 칸을 고친 뒤 저장하세요.");
        return;
      }
      settleSave.disabled = true;
      fetch("/attendance/work/settlement/save", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ym: box.dataset.ym, employee_id: box.dataset.employee, weeks: collect() }),
      }).then(function (r) { return r.json(); }).then(function (res) {
        settleSave.disabled = false;
        if (!res.ok) {
          valid = false;
          showErrors(res.errors || ["저장하지 못했습니다."]);
          updateButtons();
          return;
        }
        settleDirty = false;
        window.location.href = res.redirect;   // 같은 달로 돌아와 이 직원의 정산 팝업을 다시 연다
      }).catch(function () {
        settleSave.disabled = false;
        showErrors(["저장 요청에 실패했습니다. 프로그램을 다시 실행한 뒤 화면을 새로고침해 주세요."]);
        updateButtons();
      });
    };
  }

  settlePrint.addEventListener("click", function (e) {
    if (settlePrint.classList.contains("disabled")) {
      e.preventDefault();
      alert("잘못 입력한 칸이 있습니다. 빨간 안내를 확인한 뒤 인쇄하세요.");
    }
  });

  document.querySelectorAll(".settle-btn").forEach(function (btn) {
    btn.addEventListener("click", function () {
      const tpl = document.getElementById(btn.dataset.template);
      settleBody.innerHTML = "";
      settleBody.appendChild(tpl.content.cloneNode(true));
      bindTax(false);
      bindWeekEdit(btn.dataset.print);
      settleDlg.showModal();
    });
  });
  // 저장 후 돌아오면(?settle=직원 id) 그 직원의 정산 팝업을 다시 연다
  (function () {
    const id = new URLSearchParams(window.location.search).get("settle");
    const btn = id && document.querySelector('.settle-btn[data-template="settle-' + CSS.escape(id) + '"]');
    if (btn) btn.click();
  })();

  // ---------- 근무 추가 ----------
  const addDlg = document.getElementById("add-dialog");
  const addForm = document.getElementById("add-form");
  const addSelect = document.getElementById("add-employee");
  const ACTIVE = JSON.parse(document.getElementById("active-employees").textContent);
  const TAKEN = JSON.parse(document.getElementById("taken").textContent);

  document.querySelectorAll(".add-btn").forEach(function (btn) {
    btn.addEventListener("click", function () {
      const date = btn.dataset.date;
      const taken = new Set((TAKEN[date] || []).map(String));
      // 그날 기록이 있는 직원, 입사일 이전·퇴사일 이후인 직원은 제외 ('YYYY-MM-DD' 문자열 비교)
      const available = ACTIVE.filter(function (emp) {
        return !taken.has(String(emp.id)) && !(emp.hire_date && date < emp.hire_date) &&
          !(emp.retire_date && date > emp.retire_date);
      });
      document.getElementById("add-title").textContent =
        btn.dataset.label + " 근무 추가" + (btn.dataset.closed ? " (가게 휴일)" : "");
      document.getElementById("add-date").value = date;
      addSelect.innerHTML = "";
      available.forEach(function (emp) {
        const opt = document.createElement("option");
        opt.value = emp.id;
        opt.textContent = emp.name;
        addSelect.appendChild(opt);
      });
      // 고른 직원의 그 요일 기본 일정(시간·휴게)을 기본값으로
      const weekday = String((new Date(date + "T00:00:00").getDay() + 6) % 7);   // 0=월 ~ 6=일
      function applySchedule() {
        const emp = available.find(function (x) { return String(x.id) === addSelect.value; });
        const sch = emp && emp.schedule && emp.schedule[weekday];
        if (sch) {
          addForm.querySelector('[name="start_time"]').value = sch[0];
          addForm.querySelector('[name="end_time"]').value = sch[1];
          addForm.querySelector('[name="break_minutes"]').value = String(sch[2]);
        } else {
          addForm.querySelector('[name="break_minutes"]').value = "0";
        }
        showNet(addForm);
      }
      addSelect.onchange = applySchedule;
      applySchedule();
      const none = available.length === 0;
      document.getElementById("add-empty").hidden = !none;
      addSelect.disabled = none;
      document.getElementById("add-submit").disabled = none;
      addDlg.showModal();
    });
  });

  addForm.addEventListener("submit", function (e) { checkRange(addForm, e); });
})();
