// data-confirm 속성이 있는 폼은 제출 전에 확인을 받는다.
document.addEventListener("submit", function (e) {
  const msg = e.target.dataset && e.target.dataset.confirm;
  if (msg && !window.confirm(msg)) e.preventDefault();
});
