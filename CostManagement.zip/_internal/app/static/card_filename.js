// 카드 이용내역 업로드 파일명 규칙 — 서버 app/services/card_import/filename.py 와 같은 규칙·문구.
// 규칙을 바꾸면 두 곳을 함께 고친다 (tests/test_card_filename.py 가 node 로 이 파일을 실행해 결과를 비교한다).
//   {카드사}_{YYYYMM}.{xls|xlsx}  또는  {카드사}_{YYYYMM}_{임의문자}.{확장자}
// 카드사 목록은 인자로 받는다 (화면에서는 서버 상수 CARD_COMPANIES 를 템플릿이 넣어 준다).
(function (root) {
  var ALLOWED_EXTENSIONS = ["xls", "xlsx"];
  var MSG_FORMAT = "파일명은 카드사_년월 형식이어야 합니다";
  var MSG_CARD = "등록되지 않은 카드사입니다: ";
  var MSG_YM = "년월은 YYYYMM 형식이어야 합니다 (예: 202609)";
  var MSG_EXT = "xls, xlsx 파일만 업로드할 수 있습니다";

  function parseCardFilename(name, cardCompanies) {
    name = String(name || "").normalize("NFC").trim();
    name = name.split(/[\\/]/).pop();
    var result = { file_name: name, card_company: "", year: 0, month: 0, errors: [] };

    var dot = name.lastIndexOf(".");
    var stem = dot >= 0 ? name.slice(0, dot) : name;
    var ext = dot >= 0 ? name.slice(dot + 1).toLowerCase() : "";
    if (dot < 0 || ALLOWED_EXTENSIONS.indexOf(ext) < 0) result.errors.push(MSG_EXT);

    var parts = stem.split("_");
    if (parts.length < 2 || !parts[0] || !parts[1]) {
      result.errors.push(MSG_FORMAT);
      return result;
    }
    var card = parts[0], ym = parts[1];
    if (cardCompanies.indexOf(card) >= 0) result.card_company = card;
    else result.errors.push(MSG_CARD + card);
    var m = /^(\d{4})(\d{2})$/.exec(ym);
    var year = m ? Number(m[1]) : 0, month = m ? Number(m[2]) : 0;
    if (m && year >= 2000 && year <= 2100 && month >= 1 && month <= 12) {
      result.year = year;
      result.month = month;
    } else {
      result.errors.push(MSG_YM);
    }
    return result;
  }

  // 여러 파일 검사: 위반 파일이 하나라도 있으면 ok=false (화면은 업로드 전체를 취소하고 서버로 보내지 않는다)
  function checkCardFiles(names, cardCompanies) {
    var bad = names.map(function (n) { return parseCardFilename(n, cardCompanies); })
                   .filter(function (r) { return r.errors.length > 0; });
    return { ok: bad.length === 0, bad: bad };
  }

  root.parseCardFilename = parseCardFilename;
  root.checkCardFiles = checkCardFiles;
  if (typeof module !== "undefined" && module.exports) {
    module.exports = { parseCardFilename: parseCardFilename, checkCardFiles: checkCardFiles };
  }
})(typeof window !== "undefined" ? window : this);
