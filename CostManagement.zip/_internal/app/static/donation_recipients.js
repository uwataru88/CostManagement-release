// 기부처관리: 기부처 등록·수정 팝업 (행 클릭 → 수정). 검증·중복 검사는 서버(services/donation_service.py).
(function () {
  const dlg = document.getElementById("recipient-dialog");
  const form = document.getElementById("recipient-form");
  const el = form.elements;
  const nameError = form.querySelector('[data-error-for="name"]');

  function clearServerErrors() {
    const box = form.querySelector(".modal-errors");
    if (box) box.remove();
  }
  function clearNameError() { nameError.hidden = true; nameError.textContent = ""; el.name.classList.remove("invalid"); }
  el.name.addEventListener("input", clearNameError);

  function open(d) {
    clearServerErrors();
    clearNameError();
    el.id.value = d ? d.id : "";
    form.action = d ? "/sales/donations/recipients/" + d.id + form.dataset.query : form.dataset.newAction;
    document.getElementById("recipient-title").textContent = d ? "기부처 수정" : "기부처 등록";
    el.name.value = d ? d.name : "";
    el.reg_no.value = d ? d.regNo : "";
    el.contact.value = d ? d.contact : "";
    el.address.value = d ? d.address : "";
    dlg.showModal();
    el.name.focus();
  }

  form.addEventListener("submit", function (e) {
    if (!el.name.value.trim()) {  // 편의용 검사 (서버도 검사)
      e.preventDefault();
      nameError.textContent = "기부처명을 입력하세요.";
      nameError.hidden = false;
      el.name.classList.add("invalid");
      el.name.focus();
    }
  });

  document.getElementById("new-recipient").addEventListener("click", function () { open(null); });
  document.querySelectorAll(".recipient-row").forEach(function (row) {
    row.addEventListener("click", function (e) {
      if (e.target.closest("form, button")) return;  // 삭제 버튼은 수정 팝업을 열지 않음
      open(row.dataset);
    });
    row.addEventListener("keydown", function (e) { if (e.key === "Enter" && e.target === row) open(row.dataset); });
  });

  dlg.querySelector(".close-dialog").addEventListener("click", function () { dlg.close(); });
  dlg.addEventListener("cancel", function (e) { e.preventDefault(); });

  // 서버 검증 오류로 다시 그려진 경우: 입력값 그대로 팝업 다시 열기
  if (dlg.dataset.open) {
    const id = el.id.value;
    form.action = id ? "/sales/donations/recipients/" + id + form.dataset.query : form.dataset.newAction;
    document.getElementById("recipient-title").textContent = id ? "기부처 수정" : "기부처 등록";
    dlg.showModal();
  }
})();
