// 직원 목록: [퇴사] → 퇴사일(필수) 입력 팝업. 검사는 서버(employee_service.delete_employee)도 한다
(function () {
  const dlg = document.getElementById("retire-dialog");
  if (!dlg) return;
  const form = document.getElementById("retire-form");
  const input = document.getElementById("retire-date");
  document.querySelectorAll(".retire-btn").forEach(function (btn) {
    btn.addEventListener("click", function () {
      form.action = btn.dataset.action;
      document.getElementById("retire-title").textContent = "'" + btn.dataset.name + "' 퇴사 처리";
      input.value = btn.dataset.retire || "";   // 미리 넣어 둔 퇴사일이 있으면 그 날짜
      input.min = btn.dataset.hire || "1950-01-01";   // 입사일보다 빠를 수 없다
      dlg.showModal();
      input.focus();
    });
  });
  dlg.querySelector(".close-dialog").addEventListener("click", function () { dlg.close(); });
})();
