// 원가계산기: 제품 + 개수 행을 입력하면 소계와 총 원가를 표시한다.
// 계산은 서버(POST /cost/calculator, Decimal)에서 하고 결과만 표시한다.
(function () {
  const form = document.getElementById("calc-form");
  const tbody = document.getElementById("item-rows");
  const template = document.getElementById("row-template");
  const totalEl = document.getElementById("total-cost");
  const totalCountEl = document.getElementById("total-count");
  const PRODUCTS = JSON.parse(document.getElementById("product-data").textContent);

  form.addEventListener("submit", function (e) { e.preventDefault(); });

  // ---------- 행 관리 ----------
  function rows() { return Array.from(tbody.querySelectorAll(".item-row")); }

  function selectedIds(exceptRow) {
    const ids = new Set();
    rows().forEach(function (r) {
      if (r === exceptRow) return;
      const v = r.querySelector('input[name="product_id"]').value;
      if (v) ids.add(v);
    });
    return ids;
  }

  function addRow(focus) {
    const frag = template.content.cloneNode(true);
    const row = frag.querySelector(".item-row");
    tbody.appendChild(frag);
    setupRow(row);
    if (focus) row.querySelector(".combo-input").focus();
    return row;
  }

  function removeRow(row) {
    row.remove();
    if (rows().length === 0) addRow(false);
    scheduleCalc();
  }

  function setupRow(row) {
    const count = row.querySelector('input[name="count"]');

    Combobox.attach({
      input: row.querySelector(".combo-input"),
      hidden: row.querySelector('input[name="product_id"]'),
      list: row.querySelector(".combo-list"),
      items: PRODUCTS,
      label: function (p) { return p.name + " (1개 " + p.per_unit + "원)"; },
      isUsed: function (p) { return selectedIds(row).has(String(p.id)); },
      emptyText: "일치하는 제품이 없습니다",
      onChoose: function (p, info) {
        if (!count.value.trim()) count.value = "1";
        if (!info.byBlur) { count.focus(); count.select(); }
        scheduleCalc();
      },
      onClear: scheduleCalc,
    });

    count.addEventListener("input", function () {
      const v = count.value.replace(/,/g, "").trim();
      count.classList.toggle("invalid", v !== "" && !(/^\d+$/.test(v) && Number(v) >= 1));
      scheduleCalc();
    });
    row.querySelector(".remove-row").addEventListener("click", function () { removeRow(row); });
  }

  // ---------- 계산 ----------
  let timer = null;
  let seq = 0;

  function scheduleCalc() {
    clearTimeout(timer);
    timer = setTimeout(calc, 120);
  }

  function calc() {
    const mySeq = ++seq;
    fetch("/cost/calculator", { method: "POST", body: new FormData(form) })
      .then(function (r) { return r.json(); })
      .then(function (res) {
        if (mySeq !== seq) return; // 더 최신 요청이 있으면 무시
        rows().forEach(function (row, idx) {
          const line = res.lines[idx];
          const selected = PRODUCTS.find(function (p) {
            return String(p.id) === row.querySelector('input[name="product_id"]').value;
          });
          row.querySelector(".per-unit-cell").textContent = selected ? selected.per_unit + "원" : "-";
          row.querySelector(".subtotal").textContent = line ? line.subtotal + "원" : "-";
        });
        totalEl.textContent = res.total + "원";
        totalCountEl.textContent = res.total_count;
      })
      .catch(function () { /* 로컬 서버 일시 오류는 무시, 다음 입력 때 재시도 */ });
  }

  document.getElementById("add-row").addEventListener("click", function () { addRow(true); });
  document.getElementById("reset").addEventListener("click", function () {
    rows().forEach(function (r) { r.remove(); });
    addRow(true);
    scheduleCalc();
  });
  rows().forEach(setupRow);
})();
