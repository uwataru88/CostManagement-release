// 제품 등록/수정 폼: 검색 가능한 재료 선택, 행 추가/삭제, 실시간 원가 계산.
// 원가 계산은 서버(/cost/products/preview, Decimal)에서 하고 결과만 표시한다.
(function () {
  const form = document.getElementById("product-form");
  const tbody = document.getElementById("item-rows");
  const template = document.getElementById("row-template");
  const totalEl = document.getElementById("total-cost");
  const perUnitEl = document.getElementById("per-unit-cost");
  const formulaEl = document.getElementById("per-unit-formula");
  const weightEl = document.getElementById("per-unit-weight");
  const weightFormulaEl = document.getElementById("weight-formula");
  const weightExcludedEl = document.getElementById("weight-excluded");
  const yieldInput = form.querySelector('input[name="yield_count"]');
  const INGREDIENTS = JSON.parse(document.getElementById("ingredient-data").textContent);
  const byId = new Map(INGREDIENTS.map(function (i) { return [String(i.id), i]; }));

  // ---------- 행 관리 ----------
  function rows() { return Array.from(tbody.querySelectorAll(".item-row")); }

  function selectedIds(exceptRow) {
    const ids = new Set();
    rows().forEach(function (r) {
      if (r === exceptRow) return;
      const v = r.querySelector('input[name="ingredient_id"]').value;
      if (v) ids.add(v);
    });
    return ids;
  }

  function addRow(focus) {
    const frag = template.content.cloneNode(true);
    const row = frag.querySelector(".item-row");
    tbody.appendChild(frag);
    setupRow(row);
    if (focus) row.querySelector(".combo-input").focus();
    return row;
  }

  function removeRow(row) {
    row.remove();
    if (rows().length === 0) addRow(false);
    schedulePreview();
  }

  // ---------- 재료 선택 (combobox.js) ----------
  function setupRow(row) {
    const unitEl = row.querySelector(".unit");
    const qty = row.querySelector('input[name="quantity"]');

    Combobox.attach({
      input: row.querySelector(".combo-input"),
      hidden: row.querySelector('input[name="ingredient_id"]'),
      list: row.querySelector(".combo-list"),
      items: INGREDIENTS,
      label: function (ing) { return ing.name + " (" + ing.unit_price + "원/" + ing.unit + ")"; },
      isUsed: function (ing) { return selectedIds(row).has(String(ing.id)); },
      emptyText: "일치하는 원재료가 없습니다",
      onChoose: function (ing, info) {
        unitEl.textContent = ing.unit;
        if (!info.byBlur) qty.focus();
        schedulePreview();
      },
      onClear: function () {
        unitEl.textContent = "";
        schedulePreview();
      },
    });

    qty.addEventListener("input", schedulePreview);
    row.querySelector(".remove-row").addEventListener("click", function () { removeRow(row); });
  }

  // ---------- 실시간 원가 ----------
  let timer = null;
  let seq = 0;

  function schedulePreview() {
    clearTimeout(timer);
    timer = setTimeout(preview, 150);
  }

  function preview() {
    const mySeq = ++seq;
    const data = new FormData(form);
    fetch("/cost/products/preview", { method: "POST", body: data })
      .then(function (r) { return r.json(); })
      .then(function (res) {
        if (mySeq !== seq) return; // 더 최신 요청이 있으면 무시
        rows().forEach(function (row, idx) {
          const line = res.lines[idx];
          const ing = byId.get(row.querySelector('input[name="ingredient_id"]').value);
          row.querySelector(".unit-price").textContent = line && ing ? line.unit_price + "원/" + ing.unit : "-";
          row.querySelector(".line-cost").textContent = line ? line.cost + "원" : "-";
        });
        totalEl.textContent = res.total + "원";
        perUnitEl.textContent = res.per_unit === null ? "-" : res.per_unit + "원";
        formulaEl.textContent = res.per_unit === null ? "" : res.total + "원 ÷ " + yieldInput.value.trim() + "개";
        const w = res.weight;
        weightEl.textContent = w.per_unit === null ? "-" : w.per_unit + "g";
        weightFormulaEl.textContent = w.per_unit === null ? "" : w.batch + "g ÷ " + yieldInput.value.trim() + "개";
        weightExcludedEl.textContent = w.excluded.length ? "· 개당 무게가 없는 재료(" + w.excluded.join(", ") + ")는 무게에서 제외" : "";
      })
      .catch(function () { /* 로컬 서버 일시 오류는 무시, 다음 입력 때 재시도 */ });
  }

  // ---------- 제출 전 클라이언트 검증 ----------
  form.addEventListener("submit", function (e) {
    const problems = [];
    const seen = new Set();
    rows().forEach(function (row, idx) {
      const id = row.querySelector('input[name="ingredient_id"]').value;
      const text = row.querySelector(".combo-input").value.trim();
      const q = row.querySelector('input[name="quantity"]').value.trim();
      if (!id && !text && !q) return; // 빈 행은 무시
      if (!id) { problems.push((idx + 1) + "번째 행: 목록에서 재료를 선택하세요."); return; }
      if (seen.has(id)) problems.push("'" + byId.get(id).name + "'이(가) 중복으로 추가되었습니다.");
      seen.add(id);
      const n = Number(q.replace(/,/g, ""));
      if (!q || !isFinite(n) || n <= 0) problems.push("'" + byId.get(id).name + "' 사용량은 0보다 큰 숫자로 입력하세요.");
    });
    if (seen.size === 0) problems.push("재료를 한 개 이상 추가하세요.");
    if (!/^\d+$/.test(yieldInput.value.replace(/,/g, "").trim()) || Number(yieldInput.value.replace(/,/g, "")) < 1)
      problems.push("생산 수량은 1 이상의 정수로 입력하세요.");
    if (problems.length) { e.preventDefault(); alert(problems.join("\n")); }
  });

  // ---------- 레시피 ----------
  const hasRecipe = document.getElementById("has-recipe");
  const recipeField = document.getElementById("recipe-field");
  const recipe = document.getElementById("recipe");
  const recipeCount = document.getElementById("recipe-count");

  function updateRecipeCount() {
    const n = recipe.value.length;
    recipeCount.textContent = n.toLocaleString("ko-KR");
    recipeCount.parentElement.classList.toggle("full", n >= Number(recipe.maxLength));
  }
  hasRecipe.addEventListener("change", function () {
    if (!hasRecipe.checked && recipe.value.trim() &&
        !confirm("체크를 해제하고 저장하면 입력한 레시피가 삭제됩니다. 해제할까요?")) {
      hasRecipe.checked = true;
      return;
    }
    recipeField.hidden = !hasRecipe.checked;
    if (hasRecipe.checked) recipe.focus();
  });
  recipe.addEventListener("input", updateRecipeCount);
  updateRecipeCount();

  document.getElementById("add-row").addEventListener("click", function () { addRow(true); });
  yieldInput.addEventListener("input", schedulePreview);
  rows().forEach(setupRow);
})();

// ---------- 등록 폼 [복사하기]: 기존 제품을 골라 그 정보로 새 등록 폼을 다시 연다 (저장은 [등록]을 눌러야) ----------
(function () {
  const dataEl = document.getElementById("copy-data");
  if (!dataEl) return;  // 수정 화면이거나 제품이 하나도 없으면 복사 막대가 없다
  const input = document.getElementById("copy-input");
  const hidden = document.getElementById("copy-id");
  const btn = document.getElementById("copy-btn");
  window.Combobox.attach({
    input: input,
    hidden: hidden,
    list: input.parentNode.querySelector(".combo-list"),
    items: JSON.parse(dataEl.textContent),
    label: function (item) { return item.name; },
    isUsed: function () { return false; },
    emptyText: "일치하는 제품이 없습니다",
    onChoose: function () { btn.disabled = false; },
    onClear: function () { btn.disabled = true; },
  });

  // 지금 폼에 입력한 내용이 있으면 덮어쓰기 전에 확인
  function dirty() {
    const form = document.getElementById("product-form");
    const name = form.querySelector('input[name="name"]').value.trim();
    const anyItem = Array.from(form.querySelectorAll('input[name="ingredient_id"]')).some(function (i) { return i.value; });
    const recipe = form.querySelector('textarea[name="recipe"]').value.trim();
    return !!(name || anyItem || recipe);
  }
  btn.addEventListener("click", function () {
    if (!hidden.value) return;
    if (dirty() && !confirm("'" + input.value + "' 제품의 정보로 등록 폼을 채울까요?\n지금 입력한 내용은 지워집니다.")) return;
    window.location.href = "/cost/products/new?copy=" + encodeURIComponent(hidden.value);
  });
})();
