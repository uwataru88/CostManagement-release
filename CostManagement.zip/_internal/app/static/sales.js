// 매출 탭: 리스트/달력 보기 전환(서버 재호출 없음), 매출 입력·수정 팝업 (항목 5개, 자동 계산 없음 — 2026-10-13).
// 금액 검증·저장·합계 집계는 서버(services/sales_service.py). 여기서는 표시용 콤마·합계만 계산한다.
(function () {
  const VIEW_KEY = "sales.view";

  // ---------- 보기 방식 (localStorage 에 기억, 저장값이 없거나 읽기 실패하면 기본값 달력) ----------
  const DEFAULT_VIEW = "calendar";
  function loadView() {
    try {
      const v = window.localStorage.getItem(VIEW_KEY);
      return v === "list" || v === "calendar" ? v : DEFAULT_VIEW;
    } catch (e) {
      return DEFAULT_VIEW;
    }
  }
  function saveView(v) {
    try { window.localStorage.setItem(VIEW_KEY, v); } catch (e) { /* 저장 실패는 무시 */ }
  }
  function applyView(v) {
    document.getElementById("view-list").hidden = v !== "list";
    document.getElementById("view-calendar").hidden = v !== "calendar";
    document.querySelectorAll('input[name="view"]').forEach(function (r) { r.checked = r.value === v; });
  }
  document.querySelectorAll('input[name="view"]').forEach(function (r) {
    r.addEventListener("change", function () { applyView(r.value); saveView(r.value); });
  });
  applyView(loadView());

  // ---------- 금액 입력: 숫자만, 천 단위 콤마 ----------
  const dlg = document.getElementById("sale-dialog");
  const form = document.getElementById("sale-form");
  // 매출 항목 (v26): 서버 sales_service.AMOUNT_FIELDS 와 같은 순서
  const FIELDS = ["card_amount", "pos_cash_amount", "easy_pay_amount", "coupang_amount", "cash_book_amount"];
  const dateInput = form.elements.sale_date;
  const dateError = document.getElementById("date-error");
  const saveBtn = document.getElementById("sale-save");
  const deleteBtn = document.getElementById("sale-delete");
  const totalEl = document.getElementById("sale-total");

  function digits(v) { return String(v || "").replace(/[^\d]/g, ""); }
  function comma(n) { return n === "" ? "" : Number(n).toLocaleString("ko-KR"); }

  function updateTotal() {
    // 전체매출 = 다섯 항목 합계 (서버 sales_service.total_of 와 같은 규칙, 표시용)
    const sum = FIELDS.reduce(function (acc, f) { return acc + Number(digits(form.elements[f].value) || 0); }, 0);
    totalEl.textContent = sum.toLocaleString("ko-KR") + "원";
  }
  let dateErr = "";
  function refreshSave() { saveBtn.disabled = !!dateErr; }

  FIELDS.forEach(function (f) {
    const input = form.elements[f];
    input.addEventListener("input", function () {
      // 커서 뒤 숫자 개수를 유지해 콤마가 붙어도 입력 위치가 튀지 않게 한다
      const afterCaret = digits(input.value.slice(input.selectionStart)).length;
      input.value = comma(digits(input.value).replace(/^0+(?=\d)/, ""));
      let pos = input.value.length, seen = 0;
      while (pos > 0 && seen < afterCaret) { pos--; if (/\d/.test(input.value[pos])) seen++; }
      input.setSelectionRange(pos, pos);
      updateTotal();
    });
  });

  // ---------- 팝업 열기 ----------
  let mode = "new";      // "new" | "edit"
  let editId = "";
  let prevDate = "";

  function setDateError(text) {
    dateErr = text || "";
    dateError.textContent = dateErr;
    dateError.hidden = !dateErr;
    dateInput.classList.toggle("invalid", !!dateErr);
    refreshSave();
  }

  function fill(values) {
    FIELDS.forEach(function (f) { form.elements[f].value = values ? comma(digits(values[f])) : ""; });
    updateTotal();
  }

  function setMode(newMode, id) {
    mode = newMode;
    editId = id || "";
    form.elements.id.value = editId;
    form.action = mode === "edit" ? "/sales/records/" + editId : form.dataset.newAction;
    document.getElementById("sale-title").textContent = mode === "edit" ? "매출 수정" : "매출 입력";
    deleteBtn.hidden = mode !== "edit";
  }

  function openNew(dateStr) {
    setMode("new");
    dateInput.value = dateStr || form.dataset.defaultDate;
    prevDate = dateInput.value;
    fill(null);
    setDateError("");
    dlg.showModal();
    form.elements[FIELDS[0]].focus();
  }

  function openEdit(d) {
    setMode("edit", d.id);
    dateInput.value = d.date;
    prevDate = d.date;
    fill(d);   // data-card_amount 등 → dataset.card_amount
    setDateError("");
    dlg.showModal();
  }

  document.getElementById("new-sale").addEventListener("click", function () { openNew(); });

  // 리스트 행 / 달력 칸 클릭
  function bindOpen(el) {
    function go() {
      if (el.dataset.id) openEdit(el.dataset);
      else openNew(el.dataset.date);
    }
    el.addEventListener("click", go);
    el.addEventListener("keydown", function (e) { if (e.key === "Enter") go(); });
  }
  document.querySelectorAll(".sale-row, .sale-cell").forEach(bindOpen);

  // ---------- 날짜 변경: 같은 날짜 중복 확인 (다른 달 날짜도 서버에 확인) ----------
  dateInput.addEventListener("change", function () {
    const day = dateInput.value;
    setDateError("");
    if (!day) return;
    fetch("/sales/day?day=" + encodeURIComponent(day))
      .then(function (r) { return r.json(); })
      .then(function (res) {
        if (dateInput.value !== day) return; // 그 사이 다른 날짜를 골랐으면 무시
        if (!res.exists || String(res.id) === String(editId)) { prevDate = day; return; }
        if (mode === "new") {
          if (confirm("이미 등록된 날짜입니다. 수정하시겠습니까?")) {
            setMode("edit", res.id);
            fill(res);
            prevDate = day;
          } else {
            dateInput.value = prevDate;
          }
        } else {
          setDateError("그 날짜에는 이미 매출이 등록되어 있습니다. 다른 날짜를 고르세요.");
        }
      })
      .catch(function () { /* 확인 실패 시 서버 저장 단계에서 다시 검사한다 */ });
  });

  // ---------- 삭제 / 닫기 ----------
  deleteBtn.addEventListener("click", function (e) {
    if (!confirm(dateInput.value + " 매출을 삭제할까요?")) { e.preventDefault(); return; }
    deleteBtn.formAction = "/sales/records/" + editId + "/delete";
  });
  // 팝업은 [닫기] 버튼(또는 저장·삭제)으로만 닫는다 — 바깥 클릭·Esc 로는 닫히지 않음 (입력 중 실수로 닫히는 것 방지)
  dlg.querySelector(".close-dialog").addEventListener("click", function () { dlg.close(); });
  dlg.addEventListener("cancel", function (e) { e.preventDefault(); });
  dlg.addEventListener("keydown", function (e) { if (e.key === "Escape") e.preventDefault(); });

  // 서버 검증 오류로 다시 그려진 경우: 입력값 그대로 팝업 다시 열기
  if (dlg.dataset.open) {
    const id = form.elements.id.value;
    setMode(id ? "edit" : "new", id);
    prevDate = dateInput.value;
    const values = {};
    FIELDS.forEach(function (f) { values[f] = form.elements[f].value; });
    fill(values);
    dlg.showModal();
  }
})();
