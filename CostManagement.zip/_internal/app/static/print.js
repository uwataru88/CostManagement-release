// 화면 인쇄 (매출·매입·결산통계): [인쇄] 버튼 → 지금 보이는 내용만 인쇄 (스타일: static/print_screen.css).
(function () {
  document.querySelectorAll(".print-btn").forEach(function (btn) {
    btn.addEventListener("click", function () { window.print(); });
  });
})();
