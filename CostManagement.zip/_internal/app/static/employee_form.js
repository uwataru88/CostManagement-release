// 직원 등록/수정 폼: 근무일정 행 추가/삭제, 요일 여러 개 일괄 생성, 요일 중복·시간 검사, 연락처 하이픈 표시.
// 최종 검증은 서버(services/employee_service.py)에서 다시 한다.
(function () {
  const form = document.getElementById("employee-form");
  const tbody = document.getElementById("schedule-rows");
  const template = document.getElementById("schedule-template");
  const WEEKDAYS = ["월", "화", "수", "목", "금", "토", "일"];

  function rows() { return Array.from(tbody.querySelectorAll(".schedule-row")); }
  function breakOf(r) { const s = r.querySelector('[name="break_minutes"]'); return s ? Number(s.value || 0) : 0; }
  function minutes(t) { const p = t.split(":"); return Number(p[0]) * 60 + Number(p[1]); }
  function fmtDuration(m) {
    const h = Math.floor(m / 60), r = m % 60;
    return h && r ? h + "시간 " + r + "분" : r ? r + "분" : h + "시간";
  }

  // ---------- 행별 상태 표시 (근무시간, 중복/시간 오류) ----------
  function refresh() {
    const count = {};
    rows().forEach(function (r) {
      const wd = r.querySelector('[name="weekday"]').value;
      if (wd !== "") count[wd] = (count[wd] || 0) + 1;
    });
    rows().forEach(function (r) {
      const wdSel = r.querySelector('[name="weekday"]');
      const start = r.querySelector('[name="start_time"]').value;
      const end = r.querySelector('[name="end_time"]').value;
      const hours = r.querySelector(".hours");
      const diff = minutes(end) - minutes(start);
      const brk = breakOf(r);
      const dup = wdSel.value !== "" && count[wdSel.value] > 1;
      const badBreak = diff > 0 && brk > 0 && brk >= diff;
      wdSel.classList.toggle("invalid", dup);
      r.querySelector('[name="end_time"]').classList.toggle("invalid", wdSel.value !== "" && diff <= 0);
      r.querySelector('[name="break_minutes"]').classList.toggle("invalid", wdSel.value !== "" && badBreak);
      // 실 근무시간 = 종료 − 시작 − 휴게 (서버 timeutil.net_minutes 와 같은 계산, 표시용)
      hours.textContent = dup ? "요일 중복" : diff <= 0 ? "종료가 시작보다 늦어야 함"
        : badBreak ? "휴게가 근무시간보다 김" : fmtDuration(diff - brk) + (brk ? " (휴게 " + fmtDuration(brk) + " 제외)" : "");
      hours.classList.toggle("error-text", dup || diff <= 0 || badBreak);
    });
    refreshWeekTotal();
  }

  // ---------- 1일 소정근로시간 참고: 기본 근무일정 하루 평균(30분 단위 반올림) + [근무일정 평균으로 채우기] ----------
  function dayAverage() {
    const days = rows().map(function (r) {
      if (r.querySelector('[name="weekday"]').value === "") return 0;
      return minutes(r.querySelector('[name="end_time"]').value) - minutes(r.querySelector('[name="start_time"]').value) - breakOf(r);
    }).filter(function (m) { return m > 0; });
    if (!days.length) return 0;
    const avg = days.reduce(function (x, y) { return x + y; }, 0) / days.length;
    return Math.round(avg / 30) * 30;   // 서버 employee_service.schedule_day_minutes 와 같은 규칙
  }
  function refreshWeekTotal() {
    const el = document.getElementById("schedule-day-avg");
    if (el) el.textContent = dayAverage() ? fmtDuration(dayAverage()) : "-";
  }
  const fillBtn = document.getElementById("fill-contract");
  if (fillBtn) fillBtn.addEventListener("click", function () {
    const m = dayAverage();
    if (!m) { alert("기본 근무일정이 없습니다. 아래에서 근무일정을 먼저 입력하세요."); return; }
    const input = document.getElementById("contract-hours");
    input.value = String(m / 60);  // 30분 단위 → 7.5 형식
    input.focus();
  });

  function addRow(weekday, start, end, brk) {
    const frag = template.content.cloneNode(true);
    const row = frag.querySelector(".schedule-row");
    if (weekday !== undefined) row.querySelector('[name="weekday"]').value = String(weekday);
    if (start) row.querySelector('[name="start_time"]').value = start;
    if (end) row.querySelector('[name="end_time"]').value = end;
    if (brk !== undefined && brk !== null) row.querySelector('[name="break_minutes"]').value = String(brk);
    tbody.appendChild(frag);
    setupRow(row);
    refresh();
    return row;
  }

  function setupRow(row) {
    row.querySelector(".remove-row").addEventListener("click", function () {
      row.remove();
      if (rows().length === 0) addRow();
      refresh();
    });
  }

  tbody.addEventListener("change", refresh);

  document.getElementById("add-schedule").addEventListener("click", function () {
    // 이전 행의 시간을 이어받고, 아직 없는 다음 요일을 기본 선택
    const last = rows()[rows().length - 1];
    const used = new Set(rows().map(function (r) { return r.querySelector('[name="weekday"]').value; }));
    let next;
    for (let d = 0; d < 7; d++) { if (!used.has(String(d))) { next = d; break; } }
    const row = addRow(next,
      last && last.querySelector('[name="start_time"]').value,
      last && last.querySelector('[name="end_time"]').value,
      last ? breakOf(last) : 0);
    row.querySelector('[name="weekday"]').focus();
  });

  // ---------- 일괄 생성: 고른 요일들에 같은 시작·종료시간 ----------
  // 없는 요일은 행 추가, 이미 있는 요일은 그 행의 시간만 바꾼다. 요일이 빈 행은 정리하고 월~일 순으로 정렬
  const bulkStatus = document.getElementById("bulk-status");
  function setBulkStatus(text, isError) {
    bulkStatus.textContent = text;
    bulkStatus.classList.toggle("error-text", !!isError);
  }

  function sortRows() {
    rows()
      .sort(function (a, b) {
        return Number(a.querySelector('[name="weekday"]').value) - Number(b.querySelector('[name="weekday"]').value);
      })
      .forEach(function (r) { tbody.appendChild(r); });
  }

  document.getElementById("bulk-apply").addEventListener("click", function () {
    const days = Array.from(document.querySelectorAll(".bulk-day:checked")).map(function (c) { return c.value; });
    const start = document.getElementById("bulk-start").value;
    const end = document.getElementById("bulk-end").value;
    const brk = Number(document.getElementById("bulk-break").value || 0);
    if (!days.length) { setBulkStatus("요일을 하나 이상 고르세요.", true); return; }
    if (minutes(end) <= minutes(start)) { setBulkStatus("종료시간은 시작시간보다 늦어야 합니다.", true); return; }
    if (brk && brk >= minutes(end) - minutes(start)) { setBulkStatus("휴게시간이 근무시간보다 길거나 같습니다.", true); return; }

    rows().forEach(function (r) { if (r.querySelector('[name="weekday"]').value === "") r.remove(); });
    let added = 0, changed = 0;
    days.forEach(function (d) {
      const row = rows().find(function (r) { return r.querySelector('[name="weekday"]').value === d; });
      if (row) {
        row.querySelector('[name="start_time"]').value = start;
        row.querySelector('[name="end_time"]').value = end;
        row.querySelector('[name="break_minutes"]').value = String(brk);
        changed++;
      } else {
        addRow(d, start, end, brk);
        added++;
      }
    });
    sortRows();
    refresh();
    const names = days.map(function (d) { return WEEKDAYS[Number(d)]; }).join("·");
    setBulkStatus(names + " " + start + "~" + end + (brk ? " (휴게 " + fmtDuration(brk) + ")" : "") + " — 새로 " + added + "개" + (changed ? ", 시간 변경 " + changed + "개" : "") +
                  ". 저장하려면 아래 버튼을 누르세요.", false);
    document.querySelectorAll(".bulk-day:checked").forEach(function (c) { c.checked = false; });
  });

  // ---------- 연락처: 숫자만 입력해도 하이픈 형식으로 표시 ----------
  const phone = document.getElementById("phone");
  function formatPhone(d) {
    if (d.startsWith("02")) {
      if (d.length === 9) return d.slice(0, 2) + "-" + d.slice(2, 5) + "-" + d.slice(5);
      if (d.length === 10) return d.slice(0, 2) + "-" + d.slice(2, 6) + "-" + d.slice(6);
    }
    if (d.length === 8 && d[0] === "1") return d.slice(0, 4) + "-" + d.slice(4);
    if (d.length === 11) return d.slice(0, 3) + "-" + d.slice(3, 7) + "-" + d.slice(7);
    if (d.length === 10) return d.slice(0, 3) + "-" + d.slice(3, 6) + "-" + d.slice(6);
    return d;
  }
  phone.addEventListener("blur", function () {
    const digits = phone.value.replace(/\D/g, "");
    if (digits && /^[\d\s\-().]+$/.test(phone.value)) phone.value = formatPhone(digits);
  });

  // ---------- 제출 전 검사 ----------
  form.addEventListener("submit", function (e) {
    const problems = [];
    const seen = {};
    rows().forEach(function (r) {
      const wd = r.querySelector('[name="weekday"]').value;
      if (wd === "") return;
      const label = WEEKDAYS[Number(wd)] + "요일";
      if (seen[wd]) { problems.push(label + "이 중복되었습니다. 같은 요일은 하나만 등록할 수 있습니다."); return; }
      seen[wd] = true;
      const start = r.querySelector('[name="start_time"]').value;
      const end = r.querySelector('[name="end_time"]').value;
      if (minutes(end) <= minutes(start)) problems.push(label + " 종료시간은 시작시간보다 늦어야 합니다. (" + start + "~" + end + ")");
    });
    if (problems.length) { e.preventDefault(); alert(problems.join("\n")); refresh(); }
  });

  rows().forEach(setupRow);
  refresh();
})();
