// 기부 탭: 리스트/달력 보기 전환(서버 재호출 없음, localStorage donations.view), 기부 등록·수정 팝업 (기부처는 기부처관리에 등록된 것만 드롭다운으로, 금액 콤마, 필수 항목 안내), 행 클릭 → 수정, 삭제.
// 검증·저장·월 합계는 서버(services/donation_service.py). 여기서 하는 필수 항목 검사는 편의용이다.
(function () {
  // ---------- 보기 방식 (localStorage 에 기억, 저장값이 없거나 읽기 실패하면 기본값 리스트) ----------
  const VIEW_KEY = "donations.view";
  const DEFAULT_VIEW = "list";
  function loadView() {
    try {
      const v = window.localStorage.getItem(VIEW_KEY);
      return v === "list" || v === "calendar" ? v : DEFAULT_VIEW;
    } catch (e) {
      return DEFAULT_VIEW;
    }
  }
  function saveView(v) {
    try { window.localStorage.setItem(VIEW_KEY, v); } catch (e) { /* 저장 실패는 무시 */ }
  }
  function applyView(v) {
    document.getElementById("view-list").hidden = v !== "list";
    document.getElementById("view-calendar").hidden = v !== "calendar";
    document.querySelectorAll('input[name="view"]').forEach(function (r) { r.checked = r.value === v; });
  }
  document.querySelectorAll('input[name="view"]').forEach(function (r) {
    r.addEventListener("change", function () { applyView(r.value); saveView(r.value); });
  });
  applyView(loadView());

  const dlg = document.getElementById("donation-dialog");
  const form = document.getElementById("donation-form");
  const el = form.elements;
  const deleteBtn = document.getElementById("donation-delete");

  function digits(v) { return String(v || "").replace(/[^\d]/g, ""); }
  function comma(n) { return n === "" ? "" : Number(n).toLocaleString("ko-KR"); }

  // ---------- 금액: 숫자만, 천 단위 콤마 (커서 위치 유지) ----------
  el.amount.addEventListener("input", function () {
    const input = el.amount;
    const afterCaret = digits(input.value.slice(input.selectionStart)).length;
    input.value = comma(digits(input.value).replace(/^0+(?=\d)/, ""));
    let pos = input.value.length, seen = 0;
    while (pos > 0 && seen < afterCaret) { pos--; if (/\d/.test(input.value[pos])) seen++; }
    input.setSelectionRange(pos, pos);
  });

  // ---------- 필수 항목 안내 ----------
  const FIELDS = ["donation_date", "recipient_id", "amount"];
  function errorEl(name) { return form.querySelector('[data-error-for="' + name + '"]'); }
  function setError(name, text) {
    const p = errorEl(name);
    p.textContent = text;
    p.hidden = false;
    el[name].classList.add("invalid");
  }
  function clearError(name) {
    const p = errorEl(name);
    p.textContent = "";
    p.hidden = true;
    el[name].classList.remove("invalid");
  }
  function clearErrors() { FIELDS.forEach(clearError); }
  FIELDS.forEach(function (name) {
    el[name].addEventListener("input", function () { clearError(name); });
    el[name].addEventListener("change", function () { clearError(name); });
  });

  function validate() {
    clearErrors();
    let first = null;
    function fail(name, text) { setError(name, text); if (!first) first = el[name]; }
    if (!el.donation_date.value) fail("donation_date", "기부일자를 선택하세요.");
    if (!el.recipient_id.value) fail("recipient_id", "기부처를 선택하세요.");
    if (Number(digits(el.amount.value) || 0) < 1) fail("amount", "기부금액을 1원 이상 입력하세요.");
    if (first) first.focus();
    return !first;
  }
  form.addEventListener("submit", function (e) {
    if (e.submitter === deleteBtn) return;  // 삭제는 검사하지 않음
    if (!validate()) e.preventDefault();
  });

  // ---------- 팝업 열기 ----------
  function clearServerErrors() {
    const box = form.querySelector(".modal-errors");
    if (box) box.remove();
  }
  function setMode(id) {
    el.id.value = id || "";
    form.action = id ? "/sales/donations/records/" + id + form.dataset.query : form.dataset.newAction;
    document.getElementById("donation-title").textContent = id ? "기부 수정" : "기부등록";
    deleteBtn.hidden = !id;
  }
  function openNew(day) {
    clearServerErrors();
    setMode("");
    el.donation_date.value = typeof day === "string" && day ? day : form.dataset.defaultDate;
    el.recipient_id.value = "";
    el.amount.value = "";
    el.memo.value = "";
    clearErrors();
    dlg.showModal();
    el.recipient_id.focus();
  }
  function openEdit(d) {
    clearServerErrors();
    setMode(d.id);
    el.donation_date.value = d.date;
    el.recipient_id.value = d.recipient;   // 기부처 id (등록된 기부처 드롭다운)
    el.amount.value = comma(digits(d.amount));
    el.memo.value = d.memo;
    clearErrors();
    dlg.showModal();
  }
  const newBtn = document.getElementById("new-donation");
  newBtn.addEventListener("click", function () { openNew(); });
  // 달력: 빈 곳을 누르면 그 날짜로 기부등록 (기부처가 없어 [기부등록]이 꺼져 있으면 아무것도 안 함)
  document.querySelectorAll(".donation-cell").forEach(function (cell) {
    function go() { if (!newBtn.disabled) openNew(cell.dataset.date); }
    cell.addEventListener("click", go);
    cell.addEventListener("keydown", function (e) { if (e.key === "Enter" && e.target === cell) go(); });
  });
  // 리스트 행 / 달력 칸 안의 기부 내역 → 수정 (달력 칸의 '그 날짜로 등록'까지 번지지 않게 막는다)
  document.querySelectorAll(".donation-row").forEach(function (row) {
    row.addEventListener("click", function (e) { e.stopPropagation(); openEdit(row.dataset); });
    row.addEventListener("keydown", function (e) {
      if (e.key === "Enter") { e.stopPropagation(); openEdit(row.dataset); }
    });
  });

  // ---------- 삭제 / 닫기 ----------
  deleteBtn.addEventListener("click", function (e) {
    const opt = el.recipient_id.selectedOptions[0];
    const label = (opt && opt.value ? opt.textContent.trim() : "") + " " + (el.amount.value || "0") + "원";
    if (!confirm(el.donation_date.value + " " + label + " 기부 내역을 삭제할까요?")) { e.preventDefault(); return; }
    deleteBtn.formAction = "/sales/donations/records/" + el.id.value + "/delete" + form.dataset.query;
  });
  // 매출·매입 팝업과 같이 [닫기] 버튼(또는 저장·삭제)으로만 닫는다 — 바깥 클릭·Esc 로는 닫히지 않음
  dlg.querySelector(".close-dialog").addEventListener("click", function () { dlg.close(); });
  dlg.addEventListener("cancel", function (e) { e.preventDefault(); });

  // 서버 검증 오류로 다시 그려진 경우: 입력값 그대로 팝업 다시 열기
  if (dlg.dataset.open) {
    setMode(el.id.value);
    dlg.showModal();
  }
})();
