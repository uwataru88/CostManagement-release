// 매출 리스트 수정 모드: 한 달 전체 표를 직접 입력하거나 엑셀 셀을 복사해 붙여넣고 한 번에 저장한다.
// - 붙여넣기: 고른 칸부터 오른쪽·아래로 채움.
//   붙여넣은 범위의 첫 열이 날짜(10월1일 등)면 '날짜 기준': 리스트와 같은 열 순서
//   일자 | 전체매출 | 카드매출 | 포스현금 | 간편결제 | 쿠팡이츠 | 현금장부 로 보고 전체매출(계산값)은 건너뛴다.
//   일자 뒤 금액이 5개뿐이면 카드매출부터. 날짜가 아닌 줄(제목·합계 줄)은 무시
// - 저장: POST /sales/bulk (JSON). 검증·저장은 서버(sales_service.bulk_save)에서 전부 성공 또는 전부 실패
(function () {
  const table = document.querySelector(".sales-grid");
  if (!table) return;
  const YM = table.dataset.ym.split("-").map(Number);  // [year, month]
  const readView = document.getElementById("list-read");
  const gridView = document.getElementById("list-grid");
  const btnEdit = document.getElementById("grid-edit");
  const btnSave = document.getElementById("grid-save");
  const btnCancel = document.getElementById("grid-cancel");
  const hint = document.getElementById("grid-hint");
  const status = document.getElementById("grid-status");
  const viewRadios = document.querySelectorAll('input[name="view"]');
  const rows = Array.from(table.querySelectorAll("tr.grid-row"));
  const NCOL = 5;             // 카드매출 · 포스현금 · 간편결제 · 쿠팡이츠 · 현금장부 (서버 AMOUNT_FIELDS 순서)
  const TOTAL_COLS = [0, 1, 2, 3, 4];  // 전체매출 = 다섯 항목 합계 — 서버 sales_service.total_of 와 같은 규칙 (표시용)

  function cell(r, c) { return rows[r] && rows[r].querySelectorAll(".grid-input")[c]; }
  function inputs() { return Array.from(table.querySelectorAll(".grid-input")); }

  // ---------- 값 정리 ----------
  // 엑셀에서 온 값: 콤마·원·₩·공백 제거, '-'(회계 서식의 0)은 0, '1234.00' 은 1234. 그 외 숫자가 아니면 그대로 둠(오류 표시)
  function normalize(v) {
    let t = String(v == null ? "" : v).replace(/[,\s원₩\\]/g, "");
    if (t === "-") return "0";
    const m = t.match(/^(\d+)(?:\.0+)?$/);
    return m ? String(Number(m[1])) : t;
  }
  function isValid(t) { return t === "" || /^\d+$/.test(t) && Number(t) < 1e9; }
  function comma(t) { return /^\d+$/.test(t) ? Number(t).toLocaleString("ko-KR") : t; }

  function refreshCell(input) {
    const t = normalize(input.value);
    input.classList.toggle("invalid", !isValid(t));
    input.classList.toggle("changed", t !== normalize(input.dataset.orig));
  }

  function refreshTotals() {
    const sums = [0, 0, 0, 0];
    let days = 0;
    rows.forEach(function (tr) {
      let total = 0, any = false;
      tr.querySelectorAll(".grid-input").forEach(function (inp, c) {
        const t = normalize(inp.value);
        if (t !== "") any = true;
        if (/^\d+$/.test(t)) { sums[c] += Number(t); if (TOTAL_COLS.indexOf(c) >= 0) total += Number(t); }
      });
      tr.querySelector(".row-total").textContent = any ? total.toLocaleString("ko-KR") : "";
      tr.classList.toggle("empty-row", !any);
      if (any) days++;
    });
    table.querySelectorAll("[data-sum]").forEach(function (td, c) { td.textContent = sums[c].toLocaleString("ko-KR"); });
    document.getElementById("grid-sum-total").textContent = TOTAL_COLS.reduce(function (a, c) { return a + sums[c]; }, 0).toLocaleString("ko-KR");
    document.getElementById("grid-days").textContent = "(" + days + "일)";
  }

  function changedCount() { return inputs().filter(function (i) { return i.classList.contains("changed"); }).length; }

  // ---------- 수정 모드 켜기/끄기 ----------
  let editing = false;
  function setEditing(on) {
    editing = on;
    readView.hidden = on;
    gridView.hidden = !on;
    hint.hidden = !on;
    btnEdit.hidden = on;
    btnSave.hidden = !on;
    btnCancel.hidden = !on;
    viewRadios.forEach(function (r) { r.disabled = on; });  // 수정 중에는 달력 보기로 전환하지 않음
    status.textContent = "";
    if (on) { refreshTotals(); cell(0, 0).focus(); }
  }
  function resetAll() {
    inputs().forEach(function (i) { i.value = comma(normalize(i.dataset.orig)); refreshCell(i); });
    refreshTotals();
  }

  btnEdit.addEventListener("click", function () { setEditing(true); });
  btnCancel.addEventListener("click", function () {
    if (changedCount() && !confirm("저장하지 않은 변경 내용이 있습니다. 취소하고 원래대로 되돌릴까요?")) return;
    resetAll();
    setEditing(false);
  });
  window.addEventListener("beforeunload", function (e) {
    if (editing && changedCount()) { e.preventDefault(); e.returnValue = ""; }
  });

  // ---------- 직접 입력 ----------
  table.addEventListener("input", function (e) {
    if (!e.target.classList.contains("grid-input")) return;
    refreshCell(e.target);
    refreshTotals();
  });
  table.addEventListener("focusout", function (e) {
    if (e.target.classList.contains("grid-input")) e.target.value = comma(normalize(e.target.value));
  });
  table.addEventListener("keydown", function (e) {
    const t = e.target;
    if (!t.classList.contains("grid-input")) return;
    const r = Number(t.dataset.row), c = Number(t.dataset.col);
    let next = null;
    if (e.key === "Enter" || e.key === "ArrowDown") next = cell(r + 1, c);
    else if (e.key === "ArrowUp") next = cell(r - 1, c);
    if (next) { e.preventDefault(); next.focus(); next.select(); }
  });

  // ---------- 붙여넣기 ----------
  // 날짜: 10월1일, 10월 1일, 2026년 10월 1일, 2026-10-01, 2026.10.1, 2026/10/1, 10/1, 10-01, 10/1(목) — 연도 없으면 보고 있는 달의 연도
  function parseDate(s) {
    const t = String(s).replace(/\(.*?\)/g, "").trim();
    let m = t.match(/^(\d{4})\s*[-./년]\s*(\d{1,2})\s*[-./월]\s*(\d{1,2})\s*일?\.?$/);
    if (m) return [Number(m[1]), Number(m[2]), Number(m[3])];
    m = t.match(/^(\d{1,2})\s*[-./월]\s*(\d{1,2})\s*일?\.?$/);
    if (m) return [YM[0], Number(m[1]), Number(m[2])];
    return null;
  }

  table.addEventListener("paste", function (e) {
    const target = e.target;
    if (!target.classList.contains("grid-input")) return;
    const text = (e.clipboardData || window.clipboardData).getData("text/plain");
    if (!/[\t\n]/.test(text.replace(/\r?\n$/, ""))) {
      // 값 하나: 기본 붙여넣기 후 정리
      e.preventDefault();
      target.value = comma(normalize(text.replace(/\r?\n$/, "")));
      refreshCell(target); refreshTotals();
      return;
    }
    e.preventDefault();
    const lines = text.replace(/\r/g, "").split("\n");
    while (lines.length && lines[lines.length - 1] === "") lines.pop();
    const grid = lines.map(function (l) { return l.split("\t"); });

    const nonEmpty = grid.filter(function (cols) { return cols.join("").trim() !== ""; });
    const dated = nonEmpty.filter(function (cols) { return parseDate(cols[0]); });
    // 첫 열이 날짜인 줄이 절반 이상이면 날짜 기준 (제목·합계 줄이 섞여 있어도 됨)
    const dateMode = dated.length > 0 && dated.length * 2 >= nonEmpty.length;

    let filled = 0, skipped = 0, otherMonth = 0, notDate = 0, mismatch = 0;
    function put(r, c, v) {
      const inp = cell(r, c);
      if (!inp || c >= NCOL) { skipped++; return; }
      inp.value = comma(normalize(v));
      refreshCell(inp);
      filled++;
    }
    if (dateMode) {
      nonEmpty.forEach(function (cols) {
        const d = parseDate(cols[0]);
        if (!d) { notDate++; return; }
        if (d[0] !== YM[0] || d[1] !== YM[1] || !rows[d[2] - 1]) { otherMonth++; return; }
        let amounts = cols.slice(1);
        if (amounts.length >= NCOL + 1) {
          // 일자 | 전체매출 | 카드매출 | 포스현금 | 간편결제 | 쿠팡이츠 | 현금장부 (리스트와 같은 순서) -> 전체매출은 계산값이라 건너뜀
          const total = normalize(amounts[0]);
          amounts = amounts.slice(1, NCOL + 1);
          const sum = TOTAL_COLS.reduce(function (a, c) { const t = normalize(amounts[c]); return a + (/^\d+$/.test(t) ? Number(t) : 0); }, 0);
          if (/^\d+$/.test(total) && Number(total) !== sum) mismatch++;  // 엑셀 전체매출 ≠ 다섯 항목 합계
        }
        amounts.forEach(function (v, j) { put(d[2] - 1, j, v); });
      });
    } else {
      const r0 = Number(target.dataset.row), c0 = Number(target.dataset.col);
      grid.forEach(function (cols, i) { cols.forEach(function (v, j) { put(r0 + i, c0 + j, v); }); });
    }
    refreshTotals();
    const bad = inputs().filter(function (i) { return i.classList.contains("invalid"); }).length;
    status.textContent = filled + "칸 붙여넣음" + (dateMode ? " (날짜 기준)" : "")
      + (skipped ? ", 표 밖 " + skipped + "칸 무시" : "")
      + (otherMonth ? ", " + YM[1] + "월이 아닌 날짜 " + otherMonth + "줄 무시" : "")
      + (notDate ? ", 날짜가 아닌 줄 " + notDate + "줄 무시(제목·합계 등)" : "")
      + (mismatch ? " · 엑셀 전체매출과 다섯 항목 합계가 다른 줄 " + mismatch + "개" : "")
      + (bad ? " · 숫자가 아닌 칸 " + bad + "개 (빨간 칸)" : "");
    status.classList.toggle("error-text", bad > 0 || mismatch > 0);
  });

  // ---------- 저장 ----------
  btnSave.addEventListener("click", function () {
    inputs().forEach(function (i) { i.value = comma(normalize(i.value)); refreshCell(i); });
    refreshTotals();
    const bad = inputs().filter(function (i) { return i.classList.contains("invalid"); });
    if (bad.length) {
      alert("숫자가 아닌 칸이 " + bad.length + "개 있습니다 (빨간 칸). 0 이상의 정수(원)로 고쳐 주세요.");
      bad[0].focus();
      return;
    }
    if (!changedCount()) { status.textContent = "변경된 내용이 없습니다."; return; }

    const payload = { ym: table.dataset.ym, rows: [] };
    let deletes = 0, changedDays = 0;
    rows.forEach(function (tr) {
      const ins = Array.from(tr.querySelectorAll(".grid-input"));
      const row = { sale_date: tr.dataset.date };
      ins.forEach(function (i) { row[i.dataset.field] = normalize(i.value); });
      payload.rows.push(row);
      const blank = ins.every(function (i) { return normalize(i.value) === ""; });
      const hadSale = ins.some(function (i) { return i.dataset.orig !== ""; });
      if (ins.some(function (i) { return i.classList.contains("changed"); })) changedDays++;
      if (blank && hadSale) deletes++;
    });
    if (!confirm(changedDays + "일의 매출을 저장합니다." + (deletes ? "\n다섯 칸을 모두 비운 " + deletes + "일은 매출이 삭제됩니다." : "") + "\n저장할까요?")) return;

    btnSave.disabled = true;
    fetch("/sales/bulk", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) })
      .then(function (r) { return r.json(); })
      .then(function (res) {
        if (res.ok) { editing = false; window.location.href = res.redirect; return; }
        alert("저장하지 못했습니다.\n\n" + (res.errors || []).join("\n"));
        btnSave.disabled = false;
      })
      .catch(function () { alert("저장 중 오류가 났습니다. 다시 시도해 주세요."); btnSave.disabled = false; });
  });
})();
